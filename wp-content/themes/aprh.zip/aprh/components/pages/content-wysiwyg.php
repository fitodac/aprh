<div data-aos="fade-up">
<?php the_sub_field('wysiwyg'); ?>
</div>